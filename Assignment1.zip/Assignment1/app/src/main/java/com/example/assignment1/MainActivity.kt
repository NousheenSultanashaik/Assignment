package com.example.assignment1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CompoundButton
import android.widget.ImageView

import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnmale: Button = findViewById(R.id.btnmale)
        val img: ImageView = findViewById(R.id.img)
        btnmale.setOnClickListener {
            img.setImageResource(R.drawable.boyicon)
        }

    }
}
